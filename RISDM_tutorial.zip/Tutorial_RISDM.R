## Tutorial de RISDM para webinar
# autor: David E. Uribe-Rivera
# fecha: 20 Mayo 2025

# # instalando paquetes requeridos 
# 
# # INLA para R no esta disponible en CRAN. Se descarga desde su web
# install.packages("INLA",repos=c(getOption("repos"),
#                                 INLA="https://inla.r-inla-download.org/R/stable"), dep=TRUE)
# 
# # RISDM tampoco esta disponible en CRAN. Se descarga directamente desde Github
# devtools::install_github( repo="Scott-Foster/RISDM", build_vignettes=FALSE)
# 
# # terra
# install.packages('terra')
# install.packages('geodata')


#################################################################################
# activar librerias
library(terra)
library(RISDM)


#################################################################################

# Para este tutorial usaremos RISDM para simular datos
# el paquete usa dos conjuntos de covariables, unas para el sesgo de muestreo
# incorporado en los datos PO (por esfuerzo de muestreo variable),
# y otro para la distribucion, que se representara como una realizacion (i.e. patron)
# de un proceso de puntos

# ademas, RISDM simula un efecto aleatorio espacial que es sumado al patron 
# de puntos para simular auto-correlacion o efectos latentes (no observados)

# leamos primero los predictores creados en la seccion anterior:

predictores <- rast('data/covars.tif')
names(predictores)

dataSimulada <- simulateData.isdm(
  pop.size = 850000, # tamano de la poblacion simulada
  n.PO = 1000, # numero de observaciones de solo presencia
  n.PA = 400,  # numero de observaciones de presencia-ausencia
  n.AA = 400,  # numero de observaciones de abundancia-ausencia
  distForm = ~ -1 + bio_15 + bio_4 + bio_14 + MinTemp_Min,
  biasForm = ~ 1 + HumanPopulation + sqrtAccessibility,
  distCoefs = c(1.2,  # bio_15
                -1.95, # bio_4
                0.7, # bio_14
                -1.4), # MinTemp
  biasCoefs = c(-17, # intercept
                0.9, # HumanPopulation
                -1.2), # sqrtAccessibility
  
  transect.size = 0.05, # representa el area muestreada (como proporcion del tamaño de la celdilla)
  covarBrick = predictores,  # SpatRaster con las covariables
  control = list(
    # addRandom = FALSE,
    range = 5 * max(terra::res(predictores)),  # representa el rango de alcance del efecto aleatorio
    sd = 0.5, # y su varianza a traves del espacio (algo asi como su intensidad)
    doPlot = FALSE) # apaga la creacion automatica de graficos
)

names(dataSimulada)
str(dataSimulada)
round(sum(dataSimulada$covarBrick$Intensity[], na.rm = TRUE))
# 850000

# visualicemos la intensidad simulada: log(N individuos por celda)
plot(log(dataSimulada$covarBrick$Intensity))

# y ahora el sesgo de muestreo (en escala logaritmica)
plot(log(dataSimulada$covarBrick$biasIntensity))


# Para la estimacion geoestadistica usando INLA necesitamos una geometria base
# llamada "Mesh", compuesta por triangulos.
# RISDM provee una funcion para facilitar la creacion de esta estructura que 
# facilitara los calculos. Debe tener un cierto grado de detalle, pero no demasiado
# porque si no volvera el analisis mas lento (mas triangulaciones que calcular).

meshy <- makeMesh(ras = dataSimulada$covarBrick$bio_15, # cualquier raster del brick hara de referencia espacial
                  max.n = c(3000, 500),
                  dep.range = 10000,
                  doPlot = FALSE)

checkMesh( meshy)

# vamos a guardar las formulas
distributionFormula <- formula( ~ 0 + bio_15 + bio_4 + bio_14 + MinTemp_Min) # no incluye intercepto porque va en artefactos
biasFormula <- formula( ~ 1 + HumanPopulation + sqrtAccessibility)



# entrenemos un modelo con integracion de datos PO y PA, pero sin efecto aleatorio espacial

model_1 <- isdm(
  observationList = list(
    POdat = dataSimulada$PO,
    PAdat = dataSimulada$PA),
  covars = dataSimulada$covarBrick,
  mesh = meshy,
  responseNames = c(PA = "PA"),
  sampleAreaNames = c(PO = NULL, PA = "transectArea"),
  distributionFormula = distributionFormula,
  biasFormula = biasFormula,
  artefactFormulas = list(PA =  ~ 1),
  control = list(
    addRandom = FALSE,
    S = 300, # este numero habla del tamano de la muestra para la estimacion Bayesiana...deberia ser mayor a mil para estimaciones robustas
    coord.names = c("x", "y"),
    n.threads = (parallel::detectCores()) # paraleliza algunos procesos para rapidez en computacion
  )
)

# veamos los coeficientes que estimo:
summary(model_1)


# ahora lo mismo pero con efecto aleatorio

model_2 <- isdm(
  observationList = list(
    POdat = dataSimulada$PO,
    PAdat = dataSimulada$PA),
  covars = dataSimulada$covarBrick,
  mesh = meshy,
  responseNames = c(PA = "PA"),
  sampleAreaNames = c(PO = NULL, PA = "transectArea"),
  distributionFormula = distributionFormula,
  biasFormula = biasFormula,
  artefactFormulas = list(PA =  ~ 1),
  control = list(
    addRandom = TRUE,
    S = 300, # este numero habla del tamano de la muestra para la estimacion Bayesiana...deberia ser mayor a mil para estimaciones robustas
    coord.names = c("x", "y"),
    n.threads = (parallel::detectCores()) # paraleliza algunos procesos para rapidez en computacion
  )
)

# veamos los coeficientes que estimo:
summary(model_2)




# Ahora agreguemos ademas los datos de abundancia (AA)

model_3 <- isdm(
  observationList = list(
    POdat = dataSimulada$PO,
    AAdat = dataSimulada$AA,
    PAdat = dataSimulada$PA
  ),
  covars = dataSimulada$covarBrick,
  mesh = meshy,
  responseNames = c(PA = "PA", AA = "AA"),
  sampleAreaNames = c(PO = NULL, PA = "transectArea", AA = "transectArea"),
  distributionFormula = distributionFormula,
  biasFormula = biasFormula,
  artefactFormulas = list(PA =  ~ 1, AA =  ~ 1),
  control = list(
    # standardiseCovariates = FALSE,
    # verbose = TRUE,
    addRandom = TRUE,
    coord.names = c("x", "y"),
    n.threads = (parallel::detectCores())
  )
)


summary(model_3)


# y para generar predicciones (esto no lo correremos porque tarda)

model_3$preds <- predict(
  object = model_3,
  covars = dataSimulada$covarBrick,
  S = 300, # por defecto es 500, aunque 1000 daria estimaciones mas robustas  
  intercept.terms = 'AA_Intercept', # generalmente el que mejor intercepto da
  n.batches = 20, # optimiza tiempo de computacion
  # includeBias = TRUE,  # puedes elegir si incluir el sesgo en las predicciones (por defecto, NO deberian incluirse)
  # includeRandom = FALSE,  # tambien puedes elegir si incluir el efecto aleatorio (por defecto, SI deberia incluirse)
  n.threads = parallel::detectCores() # optimiza computacion tambien usando multiples procesadores
)

# las predicciones son guardadas como un elemento mas de la lista de out del modelo
# donde el primer elemento, llamado "fields", es un raster con varias capas que resumen
# las predicciones es decir la media, mediana,  desviacion estandard, 
# valor bajo del intervalo de credibilidad (Cr.I. 2.5%) y valor alto del Intervalo 
# de credibilidad (Cr.I. 97.5%)
str(model_3$preds)
plot(model_3$preds$field) # visualizar los raster de predicciones
plot(model_3$preds$field$Median) # o solo la mediana de las predicciones

# finalmente podemos guardar el modelo completo (incluyendo predicciones) como un objeto 
# de R (.RData, y no .rds ya que contiene rasters)
save(model_3, file = 'out/model_3.RData') # el problema es que pesara bastante

# quizas mejor seria solo guardar las predicciones como geoTiff
writeRaster(model_3$preds$field,     # objeto que contiene los rasters de predicciones
            'out/Model_3_preds.tif', # archivo donde se guardaran las predicciones
            overwrite = TRUE)        # si el archivo ya existe, permite sobre-escribirlo

# comentarios finales

# como este paquete es estimado con estadistica Bayesiana no es necesario correr replicas para
# obtener variabilidad. La variabilidad es entre las distintas iteraciones del muestreo de las MCMC
# Ademas, para modelos espacialmente explicitos con efectos aleatorios espaciales generalmente
# no se recomienda hacer bloques espaciales debido a la discontinuidad de los calculos del 
# efecto aleatorio, lo cual podria contrarrestar el hecho de que cada modelo tarde un poco mas
# que modelos mas simples, ya que en este caso correr el modelo una vez basta (no asi otros 
# algoritmos, para los cuales solemos correr replicas ya sea como bootstrapping o validacion cruzada).


# Estos ISDMs permiten, en teoria, estimar cambios en la densidad poblacional a traves del espacio.
# Es decir, permiten no solo una estimacion directa de la probabilidad de ocurrencia corregida por sesgo
# de muestreo sino ademas densidad poblacional. Esta estimacion de abundancia absoluta por unidad de 
# area sera precisa SI Y SOLO SI la estimacion de los interceptos son correctas. Usar valores de priors
# informativos, que reflejen nuestra expectativa del tamano poblacional dentro del area de estudio
# deberia mejorar la estimacion del intercepto (expresado como sampling artefact en el modelo RISDM).
